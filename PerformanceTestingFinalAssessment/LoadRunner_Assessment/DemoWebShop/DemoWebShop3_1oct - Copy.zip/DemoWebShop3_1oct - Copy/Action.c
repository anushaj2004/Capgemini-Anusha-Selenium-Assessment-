Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='books' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Category",
		"RegExp=a\\ href=\"/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("styles.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("responsive.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/responsive.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("jquery.validate.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("jquery.validate.unobtrusive.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.unobtrusive.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-ui-1.10.3.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.css", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("jquery-migrate-1.2.1.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-migrate-1.2.1.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("public.common.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.common.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("public.ajaxcart.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.ajaxcart.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("jquery.nivo.slider.js", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Scripts/jquery.nivo.slider.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("nivo-slider.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/nivo-slider.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("default.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("jquery-1.10.2.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-1.10.2.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("0000015_25-virtual-gift-card_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000015_25-virtual-gift-card_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_125.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_125.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("0000204_simple-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000204_simple-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t25.inf", 
		LAST);

	web_url("0000031_build-your-own-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000031_build-your-own-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("0000215.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000215.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("0000240.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("favicon.ico", 
		"URL=https://demowebshop.tricentis.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("0000201_build-your-own-expensive-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000201_build-your-own-expensive-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t31.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790858218719\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_start_transaction("1_LaunchUrL");

	web_concurrent_start(NULL);

	web_url("top-menu-divider.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("bullet-right.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/bullet-right.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t18.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("star-x-inactive.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("loading.gif", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("star-x-active.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("top-menu-triangle.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t23.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(8);

	web_url("ui-bg_flat_75_ffffff_40x100.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t27.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("arrows.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("bullets.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t33.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_LaunchUrL",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("2_Register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=cIk6jo3rHsHsEr7RJuS7jdWzeFzf522hx76POM2crXpwo7L4DeTPf5Z82Pee068XzsRgQMz7xytgK9tz0yAQWPWcwsXjhKk4bbKndf0HM7o1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=LastName", "Value={P_LastName}", ENDITEM, 
		"Name=Email", "Value={P_Email}", ENDITEM, 
		"Name=Password", "Value={P_Password}", ENDITEM, 
		"Name=ConfirmPassword", "Value={P_Password}", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("top-menu-background.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-background.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("top-menu-list-image.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t37.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("2_Register",LR_AUTO);

	lr_think_time(31);

	lr_start_transaction("3_SelectProduct");

/*Correlation comment - Do not change!  Original value='computing-and-internet' Name ='C_Item' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Item",
		"RegExp=a\\ href=\"/(.*?)\"\\ title",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Books",
		"URL=https://demowebshop.tricentis.com/{C_Category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/registerresult/1",
		"Snapshot=t38.inf",
		"Mode=HTTP",
		LAST);


	web_concurrent_start(NULL);

	web_url("0000130_computing-and-internet_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000130_{C_Item}_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t39.inf",
		LAST);

	web_url("0000209_copy-of-computing-and-internet-ex_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000209_copy-of-{C_Item}-ex_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t40.inf",
		LAST);

	web_url("0000133_fiction_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000133_fiction_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t41.inf",
		LAST);

	web_url("0000208_fiction-ex_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000208_fiction-ex_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t42.inf",
		LAST);

	web_url("0000132_science_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000132_science_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t43.inf",
		LAST);

	web_url("0000131_health-book_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000131_health-book_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t44.inf",
		LAST);

	web_concurrent_end(NULL);

	web_url("ico-arrow-r.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-arrow-r.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t45.inf", 
		LAST);

	lr_end_transaction("3_SelectProduct",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("4_SelectItem");

	web_url("Computing and Internet",
		"URL=https://demowebshop.tricentis.com/{C_Item}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t46.inf",
		"Mode=HTTP",
		LAST);


	web_concurrent_start(NULL);

	web_url("magnific-popup.css",
		"URL=https://demowebshop.tricentis.com/Content/magnific-popup/magnific-popup.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t47.inf",
		LAST);

	web_url("jquery.magnific-popup.js",
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.magnific-popup.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t48.inf",
		LAST);

	web_url("0000130_computing-and-internet_300.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000130_{C_Item}_300.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t49.inf",
		LAST);

	web_url("0000118_blue-jeans_125.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000118_blue-jeans_125.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t50.inf",
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("free-shipping.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/free-shipping.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t51.inf", 
		LAST);

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t52.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("4_SelectItem",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("5_AddToCart");

	web_submit_data("1",
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/13/1",
		"Method=POST",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t53.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=addtocart_13.EnteredQuantity", "Value=1", ENDITEM,
		LAST);

	web_concurrent_start(NULL);

	web_url("ico-close-notification-bar.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t54.inf", 
		LAST);

	web_url("0000130_computing-and-internet_47.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000130_{C_Item}_47.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t55.inf",
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("5_AddToCart",LR_AUTO);

	lr_think_time(44);

	lr_start_transaction("6_ViewCart");

	web_url("cart",
		"URL=https://demowebshop.tricentis.com/cart",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_Item}",
		"Snapshot=t56.inf",
		"Mode=HTTP",
		LAST);

	web_url("0000130_computing-and-internet_80.jpeg",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000130_{C_Item}_80.jpeg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://demowebshop.tricentis.com/cart",
		"Snapshot=t57.inf",
		LAST);

	lr_end_transaction("6_ViewCart",LR_AUTO);

	lr_start_transaction("7_CheckOut");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t58.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7122562", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("public.accordion.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.accordion.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t59.inf", 
		LAST);

	web_url("public.onepagecheckout.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.onepagecheckout.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t60.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(11);

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790861236472", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(19);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={P_LastName}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value={P_Email}", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=sdfghj", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=wsedrftgyhu", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=drtfgyhuj", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=345698", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=3456780876", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_url("arrow-up.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/arrow-up.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t64.inf", 
		LAST);

	lr_think_time(11);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t65.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5160178", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value={P_LastName}", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_Email}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t66.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo.jpg", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CashOnDelivery/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t67.inf", 
		LAST);

	web_url("logo.jpg_2", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CheckMoneyOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t68.inf", 
		LAST);

	web_url("logo.jpg_3", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.Manual/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t69.inf", 
		LAST);

	web_url("logo.jpg_4", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.PurchaseOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t70.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t72.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_think_time(20);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t73.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t74.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("7_CheckOut",LR_AUTO);

	return 0;
}